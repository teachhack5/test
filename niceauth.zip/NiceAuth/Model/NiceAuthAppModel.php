<?php

App::uses('AppModel', 'Model');
class NiceAuthAppModel extends AppModel {
	}

?>