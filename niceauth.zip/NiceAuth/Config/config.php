<?php

$config['NiceAuth'] = array(
	'defaultGroup' => 2
	);